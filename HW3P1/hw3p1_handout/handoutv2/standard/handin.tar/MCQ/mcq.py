def question_1():
    return 'b'
    # raise NotImplementedError


def question_2():
    return "c"
    # raise NotImplementedError


def question_3():
    return "b"
    # raise NotImplementedError



def question_4():
    return "b"
    # raise NotImplementedError


def question_5():
    return "a"
    # raise NotImplementedError

