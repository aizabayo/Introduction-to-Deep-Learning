tar -cvf handin.tar --exclude='*__pycache__*' --exclude='*.pyc' models MCQ mytorch CTC

